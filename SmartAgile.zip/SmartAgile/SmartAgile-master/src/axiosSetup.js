// src/axiosSetup.js

import axios from 'axios';

const getCsrfToken = () => {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.substring(0, 10) === 'csrftoken=') {
        cookieValue = decodeURIComponent(cookie.substring(10));
        break;
      }
    }
  }
  return cookieValue;
};

const instance = axios.create({
  baseURL: 'http://localhost:8000/api', // Adjust baseURL as needed
  withCredentials: true,
  headers: {
    'X-CSRFToken': getCsrfToken(),
  },
});

export default instance;
