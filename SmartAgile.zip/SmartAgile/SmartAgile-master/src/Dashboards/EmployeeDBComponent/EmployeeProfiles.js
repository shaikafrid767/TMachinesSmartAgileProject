// src/components/EmployeeProfilePage.js
import React from "react";
const EmployeeProfilePage = () => {
  return(
    <div>
      HELLO
    </div>
  );
}
export default EmployeeProfilePage;