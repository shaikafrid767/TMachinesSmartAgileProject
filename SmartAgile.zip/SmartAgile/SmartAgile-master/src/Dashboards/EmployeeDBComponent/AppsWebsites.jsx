import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TextField,
  Button,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  CircularProgress,
} from "@mui/material";
import { format } from "date-fns";
import {
  Mail as MailIcon,
  Code as CodeIcon,
  Work as WorkIcon,
  LinkedIn as LinkedInIcon,
  Assessment as AssessmentIcon,
  VideoCall as VideoCallIcon,
  YouTube as YouTubeIcon,
  InsertChart as InsertChartIcon,
  GitHub as GitHubIcon,
  ViewList as ViewListIcon,
  Chat as ChatIcon,
  //Google as GoogleIcon,
  ChromeReaderModeOutlined as ChromeIcon
} from "@mui/icons-material";
import "./styles.css";
import { getCSRFToken } from "./csrf"; // Import the CSRF token utility

const getIcon = (app) => {
  switch (app) {
    case "Slack":
      return <ChatIcon style={{ color: "#4A154B" }} />;
    case "Gmail":
      return <MailIcon style={{ color: "#D93025" }} />;
    case "Google Chrome":
      return <ChromeIcon style={{ color: "#D93025" }} />;
    case "Visual Studio Code":
      return <CodeIcon style={{ color: "#007ACC" }} />;
    case "JIRA":
      return <WorkIcon style={{ color: "#0052CC" }} />;
    case "Chrome (LinkedIn)":
      return <LinkedInIcon style={{ color: "#0A66C2" }} />;
    case "Excel":
      return <AssessmentIcon style={{ color: "#217346" }} />;
    case "Zoom":
      return <VideoCallIcon style={{ color: "#2D8CFF" }} />;
    case "Chrome (YouTube)":
      return <YouTubeIcon style={{ color: "#FF0000" }} />;
    case "Outlook":
      return <MailIcon style={{ color: "#0078D4" }} />;
    case "PowerPoint":
      return <InsertChartIcon style={{ color: "#D24726" }} />;
    case "GitHub":
      return <GitHubIcon style={{ color: "#000000" }} />;
    case "Trello":
      return <ViewListIcon style={{ color: "#0079BF" }} />;
    default:
      return null;
  }
};

const EmployeeActivityTable = () => {
  const [dateFilter, setDateFilter] = useState("Today");
  const [startDate, setStartDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const user = JSON.parse(localStorage.getItem("user"));
    console.log("User:", user);

    if (!user) {
      console.error("User not found in localStorage");
      return;
    }
    const formData = new FormData();
    formData.append("email", user.email);

    try {
      const csrfToken = getCSRFToken(); // Get CSRF token
      const response = await axios.post(
        `http://127.0.0.1:8000/api/appdata/`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            "X-CSRFToken": csrfToken, // Include CSRF token in headers
          },
          withCredentials: true,
        }
      );
      console.log("Response:", response.data);
      setData(response.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDateFilterChange = (event) => {
    setDateFilter(event.target.value);
    if (event.target.value !== "Custom") {
      fetchData();
    }
  };

  const applyDateFilter = () => {
    fetchData();
  };

  if (loading) {
    return <CircularProgress />;
  }
  const filteredData = dateFilter === "Custom"
    ? data.filter(row => new Date(row.date) >= new Date(startDate) && new Date(row.date) <= new Date(endDate))
    : data.filter(row => {
      const rowDate = new Date(row.date);
      const today = new Date();
      const yesterday = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 1);
      const thisWeekStart = new Date(today.getFullYear(), today.getMonth(), today.getDate() - today.getDay());

      switch (dateFilter) {
        case "Today":
          return rowDate.toDateString() === today.toDateString();
        case "Yesterday":
          return rowDate.toDateString() === yesterday.toDateString();
        case "This Week":
          return rowDate >= thisWeekStart && rowDate <= new Date(thisWeekStart.getFullYear(), thisWeekStart.getMonth(), thisWeekStart.getDate() + 6);
        default:
          return true;
      }
    });
  const formatDuration = (minutes) => {
    // Calculate hours and remaining minutes
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = Math.round(minutes % 60);

    // Return formatted string
    return `${hours}:${remainingMinutes.toString().padStart(2, '0')}`;
  };

  return (
    <Box className="p-1 w-auto">
      
      <Box className="flex justify-end mb-4">
        <FormControl variant="outlined" className="mr-1">
          <InputLabel>Date Filter</InputLabel>
          <Select
            value={dateFilter}
            onChange={handleDateFilterChange}
            label="Date Filter"
          >
            <MenuItem value="Today">Today</MenuItem>
            <MenuItem value="Yesterday">Yesterday</MenuItem>
            <MenuItem value="This Week">This Week</MenuItem>
            <MenuItem value="Custom">Custom</MenuItem>
          </Select>
        </FormControl>
        {dateFilter === "Custom" && (
          <>
            <TextField
              label="From"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              InputLabelProps={{
                shrink: true,
              }}
              className="mr-4"
            />
            <TextField
              label="To"
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              InputLabelProps={{
                shrink: true,
              }}
              className="mr-2"
            />
          </>
        )}
        <Button variant="contained" color="primary" onClick={applyDateFilter}>
          Apply
        </Button>
      </Box>
      <TableContainer component={Paper}>
        <Table>
          <TableHead className="bg-gray-200">
            <TableRow className="h-2">
              <TableCell>App/Website</TableCell>
              <TableCell>Category</TableCell>
              <TableCell>Duration (min)</TableCell>
              <TableCell>Productive</TableCell>
              <TableCell>Date</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
          {filteredData.map((row, index) => (
              <TableRow key={index}>
                <TableCell>
                  <Box className="flex items-center">
                    {getIcon(row.applicationname)}
                    <span className="ml-2">{row.applicationname}</span>
                  </Box>
                </TableCell>
                <TableCell>{row.category}</TableCell>
                <TableCell>
                  <Box className="text-sm">
                    <span>{formatDuration(row.duration)} minutes</span>
                  </Box>
                </TableCell>
                <TableCell>
                  {row.category.toLowerCase() === "work" ? "Yes" : "No"}
                </TableCell>
                <TableCell>
                  {format(new Date(row.date), "yyyy-MM-dd")}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default EmployeeActivityTable;
